﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Linq;

namespace sms_pipeLine
{
    public partial class reciepient : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int is_admin = Convert.ToInt16(Session["ADMIN"]);
                if (is_admin == 0)
                {
                    EditPanel.Visible = false;
                    PPLTabPanel.Visible = false;
                }
            }

        }

       
    }
}